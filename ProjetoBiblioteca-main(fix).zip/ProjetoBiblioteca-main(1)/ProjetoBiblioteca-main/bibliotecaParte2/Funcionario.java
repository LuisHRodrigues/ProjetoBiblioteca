

public class Funcionario extends Usuario {
	private String departamento;
	private String cargo;

	public Funcionario() {
		super();
		this.departamento= "";
		this.cargo = "";
	}
	
	public Funcionario(String nome, int idade, String sexo, String telefone, String departamento, String cargo) {
		super(nome, idade, sexo, telefone);
		this.departamento = departamento;
		this.cargo = cargo;
	}

	public String getDepartamento() {
		return departamento;
	}

	public String getCargo() {
		return cargo;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}
}
